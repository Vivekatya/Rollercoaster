cost=10

age=int(input("Hello there customer, this ride has an age limit. How old are you?"))
if age<18:
  print("ooh sorry kid. You're too young")
  quit()
else:
  while True:
    band =(input("You're old enough!. Now, do you have a wristband? (y/n)"))
    if band=="y":
      print("Wonderful. That,ll be £",cost)
      break
    
    if band=="n":
      cost=cost+5
      print("Okay, that'll be £",cost)
      break
    
    else:
      print("Sorry, I didn't get that.")
    
    
      
    
  
  